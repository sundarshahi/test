var Toky = {};
var timer = null;
var timeSpent = 0;

function inject() {
	var found = false;
	var currentPage = location.pathname;
	
    if ( currentPage.match(/agent\/contacts/) ) {
		found = found || injectContactsList();
    }

    if ( currentPage.match(/agent\/properties/) ) {
		found = found || injectContactsInfo();
    }
	
	if ( found ) {
		clearTimeout(timer);
		timeSpent = 0;
		return;
	}

	timer = setTimeout(inject, 1000);
	timeSpent += 1000;

	if ( timeSpent > 4000 ) {
		clearTimeout(timer);
		timeSpent = 0;
	}
}

function injectContactsInfo() {
	var found = false;
	var elements = $('div.contact-info');

	try {
	    elements.each( function (index) {
	    	var element = $(this);
	    	var numberDiv = element.find('div').first();

	    	if ( numberDiv !== undefined && numberDiv.find('a.toky').length === 0 ) {

	    		var number = numberDiv.html();
	    		
				if ( number !== undefined ) {
					numberDiv.html( function () {
										return $(Toky.getAsLink(number)).click(function(e) { Toky.insertClickToCall(e, number); });
									});
					found = true;
				}
			}
		});
	}
	catch (e) {
		console.error(e);
	}	

	return found;
}

function injectContactsList() {
	var found = false;
	
	try {
		$("a").each(function() {
			var element = $(this);

			if ( element.attr("href") !== undefined && element.parent().find('a.toky').length === 0 && element.attr("href").indexOf("tel:") >= 0 ) {
				element.html("");
				element.parent().append( function () {
												var number = element.attr("href").replace("tel:", "");
								  				return $(Toky.getAsLink(number)).click(function(e) { Toky.insertClickToCall(e, number); });
								  			});
				found = true;	
			}
		})
	}
	catch (e) {
		console.log(e);
	}

	return found;
}

$(window).on('popstate', function() {
	setTimeout(inject, 500);
});

$("div").on('click', function() {
	setTimeout(inject, 500);
});

Toky.init = function() {
	inject();
};
