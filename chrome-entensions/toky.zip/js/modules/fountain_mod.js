var Toky = {};
var timer = null;
var timeSpent = 0;

function injectContactPage(info) {

	var found = false;
	var elements = (info)? $('a[href*="tel:"] span') : $('a[href*="tel:"]');
	try {
	
		elements.each( function (index) {

			var element = $(this),
				number = element.html().trim();

			if ( number  && element.find('a.toky').length === 0 ) {
                var insert = $(Toky.getAsIcon(number)).click(function(e) { Toky.insertClickToCall(e, number); });
                element.prepend(insert);
                if (info) {
                    element.parent().find('i').remove();
                }
				
				found = true;
			}
		});
	}
	catch (e) {
		console.error(e);
	}
	return found;
}


function inject() {

	$header = $('ul.global-nav__items.global-nav__items_secondary');
    $logo = $header.find( "span.toky_logo" );
    if ($logo.length===0) $header.prepend($(Toky.logoOnTop()).click(function(e) { Toky.insertClickToCall(e); }));


    var foundInContactPage = injectContactPage(true);
    var found = injectContactPage();
    
	found = found || foundInContactPage;

	if ( found ) {
		clearTimeout(timer);
		timeSpent = 0;
		return;
	}

	timer = setTimeout(inject, 1000);
	timeSpent += 1000;

	if ( timeSpent > 4000 ) {
		clearTimeout(timer);
		timeSpent = 0;
	}
}

$(window).on('popstate', function() {
	setTimeout(inject, 500);
});

Toky.init = function() {
	inject();
	setTimeout(function() {
		inject();
	}, 1500);
};
