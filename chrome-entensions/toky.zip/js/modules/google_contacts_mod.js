var Toky = {};
var completed = true;

function inject() {
	
	if ( !completed ) {
			console.log("not completed");
		setTimeout(function() { completed = true; }, 5000);
		return;
	}

	var found = false;

	completed = false;

	var elements = $('div').filter( function() { 
						    	return $(this).attr("data-phones") })
							.find("div[role='button']")

	elements.each( function (index) {
		var element = $(this);
		var mainDiv = $(this).parent();
		var number = element.text();

		element.removeAttr("jsaction");
		mainDiv.removeAttr("jsaction");

		// element.click(function(e) { e.preventDefault(); console.log("click on element"); });

		if ( element.find('a.toky').length == 0 && number ) {
			console.log("adding!");
			element.html(function () {
			  	  				return $(Toky.getAsLink(number)).click(function(e) { 
			  	  																e.preventDefault();
			  	  																e.stopPropagation(); 
			  	  																console.log("Calling: " + number);
			  	  																Toky.onClick(number) 
			  	  															});
			  	  			});

			found = true;
		}
	});

	completed = true;
	console.log("completed");
}

$( window ).scroll(function() {
	console.log("scrolling");
	inject();
});

Toky.init = function() {
	inject();
};
