var Toky = {};
var timer = null;
var timeSpent = 0;

function injectContactPage() {
  var found = false;
  var defaultNumber = null,
    $newCallButton = $('span[data-icon-name="calling"]').parent("button");

  var elements = $("input[data-field], textarea[data-field]").filter(
    function () {
      return (
        $(this).attr("data-field") === "phone" ||
        $(this).attr("data-field") === "mobilephone"
      );
    }
  );

  try {
    elements.each(function (index) {
      var element = $(this);
      var number = element.val();
      if (number) {
        defaultNumber = number;
      }

      if (number.length > 0 && element.parent().find("a.toky").length === 0) {
        element.attr("style", "padding-left:20px;height: 37px;");
        element.before(function () {
          return $(
            Toky.getAsIconHubspot(
              number,
              "style='position: absolute; bottom: 8px;'"
            )
          ).click(function (e) {
            Toky.insertClickToCall(e, number);
          });
        });
        found = true;
      }
    });
  } catch (e) {
    console.error(e);
  }

  var $callButton = $('a[data-type="call"]');
  if (defaultNumber && $callButton.find("a.toky").length === 0) {
    $callButton.prepend(function () {
      return $(Toky.getAsIcon(defaultNumber, "toky_icon_hubspot")).click(
        function (e) {
          Toky.insertClickToCall(e, defaultNumber);
        }
      );
    });
  }

  if (
    defaultNumber &&
    $newCallButton.length > 0 &&
    !$newCallButton.attr("toky-active")
  ) {
    $newCallButton.attr("toky-active", "active");
    $newCallButton.click(function (e) {
      Toky.insertClickToCall(e, defaultNumber);
    });
  }

  return found;
}
var defaultNumberForDealOrTicket = null;
function injectDealTicketPage() {
  var btnEngagement = $('span[data-icon-name="calling"]').parent("button"),
    contactsNumbers = $('button[data-selenium-test="contact-chicklet-phone"]');

  if (contactsNumbers.length) {
    insertInCards(contactsNumbers);
  }

  if (defaultNumberForDealOrTicket) {
    btnEngagement.click(function (e) {
      Toky.insertClickToCall(e, defaultNumberForDealOrTicket);
    });
  }
}

function insertInCards(cards) {
  cards.each(function () {
    var element = $(this),
      number = element.find("span").last().text();

    if (!defaultNumberForDealOrTicket) {
      defaultNumberForDealOrTicket = number;
    }

    if (number.length > 0 && element.parent().find("a.toky").length === 0) {
      element.parent().html(function () {
        return $(Toky.getAsLink(number)).click(function (e) {
          Toky.insertClickToCall(e, number);
        });
      });
    }
  });
}

function injectContactList() {
  var found = false;
  var elements = $("td span.text-left.truncate-text"),
    entity = null;

  // search for contact type
  if (location.pathname.match(/^\/(company|companies)/i)) {
    entity = "company";
  } else if (location.pathname.match(/^\/(contact|contacts)/i)) {
    entity = "contact";
  }

  try {
    elements.each(function (index) {
      var element = $(this),
        number = element.html(),
        numberData = {},
        hasId = null;

      numberData.entity_name = entity;

      hasId = location.pathname.match(/^.*\/(contact|company)\/([0-9]+)\/$/i);

      if (hasId && hasId.length > 1) {
        numberData.id = hasId[2];
      } else {
        var search = $(this).parents("tr");
        if (search.length > 0) {
          search = search.find("a.private-link");
          if (search.length > 0) {
            hasId = search
              .attr("href")
              .match(/^.*\/(contact|company)\/([0-9]+)\/$/i);
            if (hasId && hasId.length > 1) {
              numberData.id = hasId[2];
            }
          }
        }
      }

      if (
        number !== undefined &&
        element.parent().find("a.toky").length === 0 &&
        /(\+)?[0-9]/gi.test(number)
      ) {
        element.html(function () {
          return $(Toky.getAsLink(number)).click(function (e) {
            e.numberData = numberData;
            Toky.insertClickToCall(e, number);
          });
        });
        found = true;
      }
    });
  } catch (e) {
    console.error(e);
  }
  return found;
}

function inject() {
  var $header = $("ul.nav-links-right:first"),
    $logo = $header.find("li span.toky_logo");
  if ($logo.length === 0)
    $header.prepend(
      $(Toky.logoOnTop("li", "nav-main-item")).click(function (e) {
        Toky.insertClickToCall(e);
      })
    );

  injectDealTicketPage();
  var found = injectContactPage();
  var foundInContactPage = injectContactList();

  found = found || foundInContactPage;

  if (found) {
    clearTimeout(timer);
    timeSpent = 0;
    return;
  }

  timer = setTimeout(inject, 1000);
  timeSpent += 1000;

  if (timeSpent > 4000) {
    clearTimeout(timer);
    timeSpent = 0;
  }
}

$(window).on("popstate", function () {
  setTimeout(inject, 500);
});

$("div").on("click", function () {
  setTimeout(inject, 500);
});

Toky.init = function () {
  inject();
};
