var Toky = {};
var timer = null;
var timeSpent = 0;

function injectContactPage() {
	var found = false;
	
	// Contacts detail

	var elements = $('input[id*="Contact0Phone"]');

	try {
		elements.each( function (index) {
			var element = $(this);
			var number = element.val();	
			var container = element.parents('.field-td').find('tr:first');

			if ( number !== undefined && number.length >= 5) {
				
				if ( container.find('a.toky').length === 0 ) {
					container.append( function () {
						return $(Toky.getAsIcon(number)).click(function(e) { Toky.insertClickToCall(e, number); });
					});
					found = true;
				}
			}

		});

	}
	catch (e) {
		console.error(e);
	}	

	return found;

}
// Contact list

function injectContactList(){
	var found = false;
	var elements = $('li[name*=phoneWith] span.chunk-data');


	try {
		elements.each( function (index) {
			var element = $(this);
			var number = element.html().trim(' ');
			
			if ( number !== undefined  && element.find('a.toky').length === 0 && number.length  >= 5) {
				element.html( function () {
					return $(Toky.getAsLink(number)).click(function(e) { Toky.insertClickToCall(e, number); });
				});
				found = true;
			}
					

		});
	}
	catch (e) {
		console.error(e);
	}	
	return found;
}
	

function inject() {

	$header = $( '#secondary-nav-icon-tray' );
    $logo = $header.find( "section span.toky_logo" );
    if ($logo.length===0) $header.prepend($(Toky.logoOnTop('section','topnav-menu topnav-button')).click(function(e) { Toky.insertClickToCall(e); }));

	var found = injectContactList();
	var foundInContactPage = injectContactPage();

	found =  found || foundInContactPage;

	if ( found ) {
		clearTimeout(timer);
		timeSpent = 0;
		return;
	}

	timer = setTimeout(inject, 1000);
	timeSpent += 1000;

	if ( timeSpent > 4000 ) {
		clearTimeout(timer);
		timeSpent = 0;
	}
}

$(window).on('popstate', function() {
	setTimeout(inject, 500);
});

Toky.init = function() {
	inject();
};
