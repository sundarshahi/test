var Toky = {};
var timer = null;
var timeSpent = 0;

function inject() {


	$header = $('ol#user-menu');
    $logo = $header.find( "li span.toky_logo" );
    if ($logo.length===0) $header.prepend($(Toky.logoOnTop('li','user-menu-left')).click(function(e) { Toky.insertClickToCall(e); }));

	var found = false;
	
	// Contacts detail

	var elements = $('span.inlineEditablePhone');

	try {
		elements.each( function (index) {
			var element = $(this);

	    	if ( element.attr("data-value") !== undefined && element.attr("data-value").toLowerCase().indexOf("newvalue") ) {

	    	var number = element.attr("data-value").replace(/[^\+0-9]/g,'');

	    	var regExp = /[\+0-9]/g;
	    	var isNumber = regExp.test(number);

	    	if ( isNumber  && element.parent().find('a.toky').length === 0 ) {
	    		element.parent().append( function () {
	    			return $(Toky.getAsIcon(number)).click(function(e) { Toky.insertClickToCall(e, number); });
	    		});
	    		found = true;
	    	}
	    }

	});

	}
	catch (e) {
		console.error(e);
	}	

	// Leads list

	var elements = $('.contact-text,td.hl.leadPhone');

    try {
	    elements.each( function (index) {
	    	var element = $(this);

	    	var number = element.text().trim().replace(/[^\+0-9]/g,'');

	    	var regExp = /[\+0-9]/g;
	    	var isNumber = regExp.test(number);

	    	if ( isNumber && element.find('a.toky').length === 0 ) {
				element.html( function () {
					  				return $(Toky.getAsLink(number)).click(function(e) { Toky.insertClickToCall(e, number); });
					  			});
				found = true;
			}
		});
	}
	catch (e) {
		console.error(e);
	}

	// Lead detail

	var _leadPhone = $('span[data-name]');
	var _leadPhone2 = $('td.PHONE');

    try {
		insertInLeadDetail(_leadPhone);
		insertInContactList2(_leadPhone2);
	}
	catch (e) {
		console.error(e);
	}	


	if ( found ) {
		clearTimeout(timer);
		timeSpent = 0;
		return;
	}

	timer = setTimeout(inject, 1000);
	timeSpent += 1000;

	if ( timeSpent > 4000 ) {
		clearTimeout(timer);
		timeSpent = 0;
	}
}

function insertInLeadDetail(elements) {
	
	elements.each( function (index) {
		var element = $(this);
		var number = element.attr("data-value"); 
		var isPhone =  (/(phone|mobile|fax)/g).test(element.attr("data-name"));
		console.log(element.attr("data-name")); 

		if ( isPhone && number && number.length > 1 && element  && element.parent().find('a.toky').length === 0 ) {
			element.parent().append( function () {
				return $(Toky.getAsIcon(number)).click(function(e) { Toky.insertClickToCall(e, number); });
			});
			return true;
		}
	});
	
	return false;
}

function insertInContactList2(elements) {
	
	elements.each( function (index) {
		var element = $(this);
		var number = element.text(); 

		if ( number && number.length > 1 && element  && element.find('a.toky').length === 0 ) {
			element.append( function () {
				return $(Toky.getAsIcon(number)).click(function(e) { Toky.insertClickToCall(e, number); });
			});
			return true;
		}
	});
	
	return false;
}

Toky.init = function() {
	inject();
};
