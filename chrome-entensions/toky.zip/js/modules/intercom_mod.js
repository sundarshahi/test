var Toky = {};
var timer = null;
var timeSpent = 0;
var PHONE_REGEX = /^(\+)?[0-9]{5,}/gi;

// Contact list

function injectContactList() {
  var found = false,
    elements = $('span[data-attribute-identifier="phone"]');

  try {
    elements.each(function () {
      var element = $(this);
      var number = element.text().trim();

      if (
        number != "Unknown" &&
        PHONE_REGEX.test(number) &&
        element.parent().find("a.toky").length === 0
      ) {
        element.parent().prepend(
          $(Toky.getAsIcon(number)).click(function (e) {
            Toky.insertClickToCall(e, number);
          })
        );
        found = true;
      }
    });
  } catch (e) {
    console.error(e);
  }
  return found;
}

function injectContactPage() {
  var found = false,
    elements = $('[data-attribute="Phone"] span'),
    validNumber = null;

  try {
    elements.each(function () {
      var element = $(this);
      var number = element.text().trim();

      if (PHONE_REGEX.test(number) && element.find("a.toky").length === 0) {
        validNumber = !validNumber ? number : validNumber;
        element.prepend(
          $(Toky.getAsIcon(number)).click(function (e) {
            Toky.insertClickToCall(e, number);
          })
        );
        found = true;
      }
    });

    var $btnActions = $("div.profile__user-data__actions");
    if (validNumber && $btnActions.find("a.toky").length === 0) {
      $btnActions.prepend(
        $(Toky.btnCallIntercom(validNumber)).click(function (e) {
          Toky.insertClickToCall(e, validNumber);
        })
      );
    }
  } catch (e) {
    console.error(e);
  }
  return found;
}

function inject() {
  var $header = $("div.u__right.js_right_user_company_list_buttons"),
    $logo = $header.find("span.toky_logo");

  if ($logo.length === 0)
    // $header.prepend(
    //   $(Toky.logoOnTop()).click(function (e) {
    //     Toky.insertClickToCall(e);
    //   })
    // );

    var found = injectContactList();
  var foundInContactPage = injectContactPage();

  found = found || foundInContactPage;

  if (found) {
    clearTimeout(timer);
    timeSpent = 0;
    return;
  }

  timer = setTimeout(inject, 1000);
  timeSpent += 1000;

  if (timeSpent > 4000) {
    clearTimeout(timer);
    timeSpent = 0;
  }
}

$(window).on("popstate", function () {
  setTimeout(inject, 500);
});

Toky.init = function () {
  inject();
  setTimeout(function () {
    inject();
  }, 1500);
};
