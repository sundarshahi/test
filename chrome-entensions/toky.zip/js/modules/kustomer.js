var Toky = {},
  timer = null,
  timeSpent = 0,
  overListener = null,
  divListener = null,
  times = 0,
  list = [],
  founds = [];

function inject(reset) {
  var $header = $("div.headerRight__rightContainer___2Q30w"),
    $logo = $header.find("div span.toky_logo");

  if ($logo.length === 0) {
    $header.prepend(
      $(Toky.logoOnTop("div")).click(function (e) {
        Toky.insertClickToCall(e);
      })
    );
  }

  if (reset) {
    overListener = null;
    divListener = null;
    list = [];
    founds = [];
    times = 0;
  }

  setupListeners();

  if (founds.length == list.length && list.length > 0) {
    clearTimeout(timer);
    timeSpent = 0;
    return;
  }

  timer = setTimeout(inject, 1000);
  timeSpent += 1000;

  if (timeSpent > 4000) {
    clearTimeout(timer);
    timeSpent = 0;
  }

  var elements = $(".rc-tooltip-inner span");
  elements.each(function () {
    addCTC(this);
  });
  // console.log("inject times", times);
  times++;
}

function setupListeners() {
  var profileText = $(".headerMiddleCustomer__avatarText___vnGMT"),
    profileLink = $("div [class*=iconButton__clickable]");

  if (!overListener && profileText.length) {
    overListener = profileText.mouseover(function () {
      setTimeout(inject, 500);
    });
  }

  if (!divListener && profileLink.length) {
    divListener = profileLink.click(function () {
      setTimeout(function () {
        $("input[type=tel]").each(function () {
          addCTC(this, $(this).parents(".contactSelect__row___1H6r5"));
        });
      }, 1000);
    });
  }
}

function addCTC(object, where) {
  var element = $(object),
    number = element.hasClass("form-control") ? element.val() : element.text(),
    container = where ? where : element,
    style = where ? 'style="margin-top:10px;"' : "";

  number = number.replace(/[^+\d]/g, "");

  list.push(object);

  if (/^(\+)?[0-9]{5,}/gi.test(number)) {
    clearTimeout(timer);

    if (!container.find(".toky").length && number.length > 0) {
      container.append(function () {
        founds.push(number);
        return $(Toky.getAsIcon(number, style)).click(function (e) {
          e.preventDefault();
          e.stopPropagation();
          Toky.onClick(number);
        });
      });
    }
  }
}

Toky.init = function () {
  inject(true);
};
