Toky = {};
var timer = null;
var timeSpent = 0;
var _console = false;
var found = false;

var _isOpenTel = false;
var _subDomain = '(na96\.lightning|glovoapp)';
var _phoneIdentity = 'span.uiOutputPhone,span.forceOutputPhone,[lightning-clicktodial_clicktodial],[lightning-formattedphone_formattedphone]';

// Contact list
function searchForIframes () {
	
	var _style =  'style="float:left;height:13px;margin-right:5px;"';

	var main = document.getElementById('navigatortab')
	var iframe = main.getElementsByTagName('iframe')
	var telElement = [];
	findIframe(iframe);

		function findIframe(iframe) {
		if (iframe==null) return;

		for (let i = 0; i < iframe.length; i++) {     
			try {
				if (!iframe[i].cross) {
					var tel = iframe[i].contentDocument.querySelectorAll('span.tel');
					if (tel.length>0) {
						for (let x = 0; x < tel.length; x++) {
							telElement.push(tel[x])
						}
					}
					var newIframe = iframe[i].contentDocument.getElementsByTagName('iframe'); 
					findIframe(newIframe) 
				}
				
			}catch (e) {
				iframe[i].cross = true;			
				console.warn('Can\'t access to iframe ' + iframe[i].getAttribute('src'));
			}
		}
	}

	for (let c = 0; c < telElement.length; c++) {
		var element = $(telElement[c]),
			number = element.text();

		if ( number  && element.find('a.toky').length === 0 ) {
			element.prepend( function () {
				return buildByAction(true, number);				
			});
			found = true;
		}
	}
	

}

function injectContactList(){		
	var elements = $('span.tel'), type = 'clasic'; 
	
	if (elements.length == 0){
		type = 'lightning';
		elements = $(_phoneIdentity)
	}
	try {
		elements.each( function (index) {
			var element = $(this);
			var number = element.text().trim().replace(/[^\+0-9]/g,'');
			let extraCtrl = element.html();

			if (element.attr('toky-click-to-call') && !extraCtrl.match(/(toky_icon)/)) {
				element.removeAttr('toky-click-to-call');
			}

			if ( number  && element.attr('toky-click-to-call') === undefined ) {
				element.attr('toky-click-to-call', 'loaded');			
				var data = {newElement:element, numberData:{}};
			
				switch (type) {
					case 'clasic':
						data = loadClasicTel(element);
						found = true;
					break;
					case 'lightning':
						data = loadlightningTel(element);
						found = false;
					break;				
				}

				let strHTML = data.newElement.html();
				if (strHTML && !strHTML.match(/(slds-icon_container)/) ) {
					data.newElement.prepend( function () {					
						return buildByAction(false, number, data)					
					});	
				}
			} 								
		});
	}
	catch (e) {
		console.error(e);
	}	
	return found;
}

function buildByAction(isIframe, number, data=null) {
	var elemment = isIframe ? Toky.getAsIconIframe(number,'','', _isOpenTel) : Toky.getAsIcon(number,'',false, _isOpenTel);
	if (_isOpenTel) {
		return $(elemment).attr('number', number);
	} else {
		return $(Toky.getAsIcon(number)).click(function(e) { 
			e.numberData = data.numberData;
			Toky.insertClickToCall(e, number); 
		});		
	}
}

function loadlightningTel(element) {
	var newElement = element, numberData = {}, _parent = null, a = null;
	
	_parent = element.parents('a');
	if (_parent.length>0 && _parent.attr('data-recordid')) {
		if (_parent.attr('data-recordid').match(/^(003)/)) {
			numberData.entity_name = 'Contact';
			numberData.id = _parent.attr('data-recordid').replace(/[A-Z]{3}$/, '');
		}		
	}
	
	if (!numberData.id) {
		_parent = element.parents('div.listItemBody');
		if (_parent.length>0) {
			a = _parent.find('.primaryField a[data-recordid]');
			if (a.length>0) {
				numberData.id = a.attr('data-recordid').replace(/[A-Z]{3}$/, '');
				if (numberData.id.match(/^(003)/)) numberData.entity_name = 'Contact';
				if (numberData.id.match(/^(00Q)/)) numberData.entity_name = 'Lead';				
				if (!numberData.entity_name) numberData = {};				
			}
		}
	}
	
	if (!numberData.id) {	
		_parent = element.parents('.slds-page-header').parents('section.tabContent');		
		if (_parent.length>0) {											
			a = $('a.tabHeader[aria-controls="'+_parent.attr('id')+'"]:first');
			if (a.attr('href')) {
				var data = a.attr('href').split('/');					
				if (data[3].match(/^(contact|lead)$/i)) {
					numberData.id = data[4].replace(/[A-Z]{3}$/, '');
					if (numberData.id.match(/^(003)/)) numberData.entity_name = 'Contact';
					if (numberData.id.match(/^(00Q)/)) numberData.entity_name = 'Lead';				
					if (!numberData.entity_name) numberData = {};
				}				
			}
		}			
	}
	
	return {newElement:newElement,numberData:numberData};
} 

function loadClasicTel(element) {
	
	var newElement = element, numberData = {}, tr = newElement.parents('tr:first'), pathname = location.pathname.split('/');

	if (pathname.length>1) pathname = pathname[1];

	if (typeof pathname=='string' && pathname.match(/^\/(003|00Q)[0-9]{3}/)) {
		numberData.id = pathname;
		if (numberData.id.match(/^(003)[0-9]{3}/)) numberData.entity_name = 'Contact';
		if (numberData.id.match(/^(00Q)[0-9]{3}/)) numberData.entity_name = 'Lead';							
	} else {
		for (var i = 0; i < tr.length; i++) {
			var a = $(tr[i]).find('a');
			for (var x = 0; x < a.length; x++) {
				if (!numberData.entity_name) {
					try {
						var code = a[x].href.split('/');
						numberData.id = code[3];
						if (numberData.id.match(/^(003)[0-9]{3}/)) numberData.entity_name = 'Contact';
						if (numberData.id.match(/^(00Q)[0-9]{3}/)) numberData.entity_name = 'Lead';				
					} catch (e) {}				
				}
			}
		}		
	}
	// if (element.get(0).style.display=='none') {
	// 	var newElement = element.next(), data = newElement.find('a').attr('onclick');
	// 	if (data) {
	// 		var _get = data.split('&');
	// 		for (var i = 0; i < _get.length; i++) {
	// 			try {
	// 				if (_get[i].match(/^(ID)=/)) {
	// 					numberData.id = _get[i].replace('ID=','');
	// 				} else
	// 				if (_get[i].match(/^(ENTITY_NAME)=/)) {
	// 					numberData.entity_name = _get[i].replace('ENTITY_NAME=','');
	// 				}
	// 			} catch (e) {console.error(e)}
	// 		}
	// 	}
	// }
	//
	// if (numberData.entity_name && !numberData.entity_name.match(/^(contact|lead)$/i)) {
	// 	try {
	// 		var numberData2 = {};
	//
	// 		if (numberData.entity_name.match(/^(task)$/i)) {
	//
	// 			var a = element.parents('table').find('#tsk2_ileinner a');
	// 			if (a.length>0 && a.attr('id')) {
	// 				numberData2.id = a.attr('id').replace(/(lookup|tsk2)/g, '');
	// 				if (numberData2.id.match(/^(003)/)) numberData2.entity_name = 'Contact';
	// 				if (numberData2.id.match(/^(00Q)/)) numberData2.entity_name = 'Lead';
	// 				if (numberData2.entity_name.match(/^(contact|lead)$/i)) numberData = numberData2;
	// 			}
	// 		}
	//
	// 	} catch (e) {
	// 		console.error(e)
	// 	}
	// }
	//
	return {newElement:newElement,numberData:numberData};
	
}

var _checking = false;

function checkCurrentPage() {
    
    if ( _checking )
    	return;

    _checking = true;
    inject();
	setTimeout(function() { 
		_checking = false;	
		checkCurrentPage(); 
	}, 2000);
}

function inject() {
	
	_console = (/console/gi).test(location.href);

	if (_console) {
		var found = searchForIframes();
	} else {
		var found = injectContactList();
	}
}

function tryConfigByJSON(data) {
	try {	
		if (data.open_tel_by_sudomain) {
			var regExp = new RegExp(`^(https\:\/\/)(${data.open_tel_by_sudomain.replace('.','\.')})`, 'i');
			_isOpenTel = location.href.match(regExp)!=null;	
		}

		if (data.elements) {
			_phoneIdentity = data.elements;
		}			
		checkCurrentPage();
		
	} catch (error) {
		checkCurrentPage();		
	}	
}

$(window).on('popstate', function() {
	setTimeout(checkCurrentPage, 500);
});

Toky.init = function() {
	$.ajax({
		url: 'https://tokystorage.s3.amazonaws.com/extension/integration/salesforce/config.json',
		type: 'GET'		
	}).done(function(data){
		tryConfigByJSON(data)	
	}).fail(function(error) {
		checkCurrentPage();
	});
};
