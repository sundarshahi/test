var Toky = {};
var _timer = null;
var timeSpent = 0;
var found = false;

function inject() {
  var elements = [];
  elements = $("div .property label")
    .filter(function () {
      return $(this).text() === "Phone";
    })
    .parent()
    .parent()
    .find("[data-identity-id],.phone-text");

  var otherElements = $(
    '[data-test-id="customercontext-userinfo-phonenumber"] div'
  ).filter(function () {
    var attr = $(this).attr("data-test-id");
    return /phonenumber/g.test(attr);
  });

  elements.each(function () {
    addCTC(this);
  });

  if (otherElements.length > 0) {
    otherElements.each(function () {
      addCTC(this);
    });
  }

  checkIsInjected();
}

function addCTC(object) {
  var element = $(object);
  var number = element.text();

  if (/(\+)?[0-9]/gi.test(number)) {
    // clearTimeout(_timer);

    if (!element.hasClass("toky")) {
      element
        .filter(function () {
          return $(this).text().length !== 0;
        })
        .html(function () {
          return $(Toky.getAsLink(number)).click(function (e) {
            e.preventDefault();
            e.stopPropagation();
            Toky.onClick(number);
          });
        });
    }
  }
}

function checkIsInjected() {
  _timer = setTimeout(inject, 1000);
  timeSpent += 1000;

  if (timeSpent > 5000) {
    clearTimeout(_timer);
    _timer = null;
    timeSpent = 0;
  }
}

Toky.init = function () {
  if (_timer) {
    return;
  }

  inject();
};
