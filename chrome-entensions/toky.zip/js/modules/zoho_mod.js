var Toky = {};
var completed = true;
var timer = null;
var timeSpent = 0;
var plus = false;

function injectContact() {
  // var elements = $('a.phoneRtl');
  var _style = 'style="height:13px;margin:6px;"';
  var elements = plus
    ? $(
        document
          .getElementById("crmLoadFrame")
          .contentWindow.document.getElementById("basic")
      ).find("span.phoneRtl")
    : $("span.phoneRtl");

  if (plus) {
    _style = 'style="height:13px;margin:6px;float:left"';
  }

  elements.each(function (index) {
    var element = $(this);
    var number = element.text();
    // number = (plus) ? element.html() : element.html();
    var parent = element.parent();

    if (parent.find("a.toky").length == 0 && number) {
      // console.log("Adding for " + number);
      parent.append(function () {
        return $(Toky.getAsIconIframe(number, "", _style)).click(function (e) {
          Toky.insertClickToCall(e, number);
        });
      });
    }
  });
}

function injectSearchTable() {
  var _style = 'style="float:left;height:13px;margin:6px;"';
  var $table = plus
    ? $(
        document
          .getElementById("crmLoadFrame")
          .contentWindow.document.getElementById("gsearchDiv")
      ).find("[id^=header_]")
    : $("[id^=header_]");

  $table.each(function (index) {
    var table = $(this);

    // var mobileIndex = 3; // table.find('th:contains("Mobile")').index() + 1;
    // var phoneIndex = 5; //table.find('th:contains("Phone")').index() + 1;

    var mobileIndex = table.find('th:contains("Mobile")').index() + 1;
    var phoneIndex = table.find('th:contains("Phone")').index() + 1;

    table.find("tr").each(function () {
      var row = $(this);

      var c1 = row.find("td:nth-child(" + mobileIndex + ")");
      var c2 = row.find("td:nth-child(" + phoneIndex + ")");

      [c1, c2].forEach(function (c) {
        var number = c.text();

        if (c.find("a.toky").length == 0 && number) {
          console.log("Adding for " + number);

          c.append(function () {
            return $(Toky.getAsIconIframe(number, "", _style)).click(function (
              e
            ) {
              Toky.insertClickToCall(e, number);
            });
          });
        }
      });
    });
  });
}

function injectContactsTable() {
  var $view = $(".lyteExpTableOrigTableInnerWrap .lv_data_phone");

  //   if (plus) {
  //     $view = $(
  //       document
  //         .getElementById("crmLoadFrame")
  //         .contentWindow.document.getElementById("listViewTable")
  //     );
  //   }

  var _style = 'style="float:left;height:13px;margin:3px;"';

  $view.each(function (index) {
    var elements = $(this);

    elements.each(function () {
      var row = $(this);
      // var c = row.find('td:nth-child(4)');
      row
        .find("div.phoneRtl")
        .attr("style", "max-width:90% !important")
        // .parent()
        .each(function () {
          var c = $(this);
          var number = c.text();

          if (c.hasClass("tableHead")) return true; // continue

          if (c.find("a.toky").length == 0 && number) {
            c.prepend(function () {
              return $(Toky.getAsIconIframe(number, "", _style)).click(
                function (e) {
                  Toky.insertClickToCall(e, number);
                }
              );
            });
          }
        });
    });
  });
}

function injectZohoDesk() {
  var found = false,
    info = /(Contacts|Accounts)/g.test(location.hash),
    elements = !info ? $('a[href*="tel:"] span') : $('a[href*="tel:"]');

  try {
    elements.each(function (index) {
      var element = $(this),
        number = element.html().trim(),
        insert = false;

      if (number && element.find("a.toky").length === 0) {
        insert = $(Toky.getAsIcon(number)).click(function (e) {
          Toky.insertClickToCall(e, number);
        });
        element.prepend(insert);

        found = true;
      }
    });
  } catch (e) {
    console.error(e);
  }
  return found;
}

function insertInElements(elements) {
  var _style = 'style="float:left;height:13px;margin:6px;"';
  try {
    elements.each(function (index) {
      var element = $(this);
      var number = element.text();
      // var number = element.text().replace(/[^\+0-9]/g,'');

      if (
        number &&
        element.find("a.toky").length === 0 &&
        element.parent().find("a.toky").length === 0
      ) {
        // element.html( function () {
        // 	return $(Toky.getAsLink(number)).click(function(e) { Toky.insertClickToCall(e, number); });
        // });
        element.prepend(function () {
          return $(Toky.getAsIconIframe(number, "", _style)).click(function (
            e
          ) {
            Toky.insertClickToCall(e, number);
          });
        });
      }
    });
  } catch (e) {
    console.error(e);
  }
}

function injectOtherPages() {
  var _els = plus
    ? $(
        document
          .getElementById("crmLoadFrame")
          .contentWindow.document.getElementById("kso_social_rightpanel")
      ).find("table.contactInfo td div.fontSmoothAntialiased")
    : $("table.contactInfo td div.fontSmoothAntialiased");
  var elements = _els.filter(function () {
    return $(this).closest("tr").find(".lPhone,.mPhone").length > 0;
  });
  insertInElements(elements);

  elements = $("div.phoneicon, div.mobileicon");
  insertInElements(elements);

  if (plus) {
    elements = $(
      document
        .getElementById("crmLoadFrame")
        .contentWindow.document.getElementById("basic")
    ).find("div.phoneRtl");
    insertInElements(elements);
  }

  insertInElements($(".phoneRtl.pR"));
}

$(document).keypress(function (e) {
  console.log(e.which);
  if (e.which == 13) {
    setTimeout(check, 500);
  }
});

$(document).on("click", function () {
  setTimeout(check, 500);
});

// back button on browser
$(window).on("popstate", function () {
  setTimeout(check, 500);
});

function check() {
  var currentPage = location.href;

  if (
    currentPage.match(
      /\/ShowTab|Contacts|Leads|Accounts|Potencials|CustomModule/
    )
  ) {
    delayedInject(injectContactsTable);
  }
  if (currentPage.match(/\/EntityInfo|Contacts|Leads|Accounts|CustomModule/)) {
    delayedInject(injectContact);
  }
  if (currentPage.match(/\/GlobalSearch/)) {
    delayedInject(injectSearchTable);
  }

  delayedInject(injectOtherPages);
  delayedInject(injectZohoDesk);

  timer = setTimeout(check, 1000);
  timeSpent += 1000;

  if (timeSpent > 8000) {
    clearTimeout(timer);
    timeSpent = 0;
  }
}

function delayedInject(f) {
  f();
  setTimeout(f, 1000);
}

Toky.init = function () {
  plus = /crmplus/.test(location.href);

  check();

  var $header = $("#tabSettingsmenu");
  var $logo = $header.find("div span.toky_logo");
  if ($logo.length === 0)
    $header.append(
      $(Toky.logoOnTop("div", "fR")).click(function (e) {
        Toky.insertClickToCall(e);
      })
    );

  // Added Plus version

  $header = $("#crmpluscommonuitopbaroptions");
  $logo = $header.find("li span.toky_logo");
  if ($logo.length === 0)
    $header.prepend(
      $(Toky.logoOnTop("li")).click(function (e) {
        Toky.insertClickToCall(e);
      })
    );

  $header = $("ul.TpBndRhtUl");
  $logo = $header.find("li span.toky_logo");
  if ($logo.length === 0)
    $header.prepend(
      $(Toky.logoOnTop("li")).click(function (e) {
        Toky.insertClickToCall(e);
      })
    );

  if (plus) {
    $("#commonUiModuleListcrm a").click(function () {
      setTimeout(check, 1000);
    });

    document
      .getElementById("crmLoadFrame")
      .contentWindow.document.addEventListener("click", function () {
        setTimeout(check, 1000);
      });
  }
};
