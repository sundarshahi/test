Toky.onClick = function (data, extra) {
  var _data = {
    number: data,
    from: window.location.hostname,
  };

  if (extra) {
    _data.id = extra.id;
    _data.entity_name = extra.entity_name;
  }

  chrome.runtime.sendMessage({ cmd: "call", data: _data });
};

Toky.getAsLink = function (number) {
  var iconURL = chrome.extension.getURL("img/favicon.ico");
  return (
    '<a class="toky" href="#"><img alt="Call ' +
    number +
    '" class="toky_icon" src="' +
    iconURL +
    '"></img>' +
    number +
    "</a>"
  );
};

Toky.btnCallIntercom = function (number) {
  var iconURL = chrome.extension.getURL("img/favicon.ico");
  return (
    '<div class="u__left ember-view"><a class="toky btn o__secondary o__in-right-list" href="#"><img alt="Call ' +
    number +
    '" class="toky_icon" src="' +
    iconURL +
    '"></img>  Call</a></div>'
  );
};

Toky.getAsIcon = function (number, extraClasses = "", addNumber = false, addTel=false) {
  var iconURL = chrome.extension.getURL("img/favicon.ico");
  var frontText = addNumber ? number : "";
  var addTel = addTel ? `tel:${number}` : '#';
  if (extraClasses && extraClasses.indexOf("style=") >= 0)
    return `<span>${frontText}</span>&nbsp;<a class="toky" ${extraClasses} href="${addTel}"><img alt="Call ${number}" class="toky_icon" src="${iconURL}"></img></a>`;
  else  
   return `<span>${frontText}</span>&nbsp;<a class="toky ${extraClasses}" href="${addTel}"><img alt="Call ${number}" class="toky_icon" src="${iconURL}"></img></a>`;    
};

Toky.getLogoURL = function () {
  return chrome.extension.getURL("img/toky-logo.png");
};

Toky.getAsIconHubspot = function (number, extraClasses = "") {
  var iconURL = chrome.extension.getURL("img/favicon.ico");
  return (
    '<a class="toky"' +
    extraClasses +
    ' href="#"><img alt="Call ' +
    number +
    '" class="toky_icon" src="' +
    iconURL +
    '"></img></a>'
  );
};

Toky.getAsIconIframe = function (
  number,
  parentExtraClasses = "",
  extraClasses = "",
  addTel = false
) {
  var iconURL = chrome.extension.getURL("img/favicon.ico");
  var addTel = addTel ? `tel:${number}` : '#';
  return (
    '<a class="toky"' +
    parentExtraClasses +
    ' href="'+addTel+'"><img alt="Call ' +
    number +
    '" ' +
    extraClasses +
    ' class="toky_icon" src="' +
    iconURL +
    '"></img></a>'
  );
};

Toky.logoOnTop = function (element, extraClasses) {
  var logo = chrome.extension.getURL("img/favicon.ico");
  var _class = extraClasses ? extraClasses : "";

  if (element !== undefined)
    return (
      "<" +
      element +
      ' class="' +
      _class +
      '"><span class="toky_logo"><img src="' +
      logo +
      '"></span></' +
      element +
      ">"
    );
  else return '<span class="toky_logo"><img src="' + logo + '"></span>';
};

Toky.insertClickToCall = function (e, phoNumber) {
  var number = !phoNumber ? "" : phoNumber;
  e.preventDefault();
  e.stopPropagation();
  console.log("-- 📞 " + number);
  Toky.onClick(number, e.numberData);
};

$(document).ready(function () {
  console.log("-- Toky was loaded");
  Toky.init();
});

$(window).click(function () {
  console.log("-- Looking for numbers");
  timer = setTimeout(Toky.init, 1000);
});
