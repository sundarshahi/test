let _data = {};

const POPUP_WIDTH = 520;
const POPUP_HEIGHT = 720;

// var ROOT_URL = "http://127.0.0.1/business/dialer"
const ROOT_URL = "https://app.krispcall.com"

function reload (){
    window.location.reload()
}

function callOrText(info)
{
    var data = {number: info.selectionText};
    openPopup(dialerURL(data));
}

function dialerURL(data) {

    let extension = "", 
		number = data.number.replace(/[^0-9]+/gi, ''),
		id = data.id ? data.id : '',
		entity_name = data.entity_name ? data.entity_name : '';

    try {
       const hasPlus = data.number.startsWith("+");
        extension = number.match(/ext(.+)$/g);

        if ( extension == null )
            extension = number.match(/;(.+)$/g);

        if ( extension == null )
            extension = number.match(/x(.+)$/g);

        if ( extension == null )
            extension = number.match(/ex(.+)$/g);

        number = number.replace(/ext.+$/g, "");
        number = number.replace(/ex.+$/g, "");
        number = number.replace(/;.+$/g, "");
        number = number.replace(/x.+$/g, "");
        number = number.replace(/[^0-9]/g, "");
        number = number.replace(/^0/g, "");

        if ( hasPlus )
            number = "+" + number;         
    }
    catch (e) {
        console.error(e);
    }
    console.log(extension);
    if ( extension != null ) {
        extension = extension.toString().replace(/[^0-9]/g, "");
        extension = "&ext=" + extension;
    }
    else
        extension = "";

	if (typeof id=="string") extension+="&id="+id+"&entity_name="+entity_name;
	extension+="&from="+data.from;


    return ROOT_URL + "?call=" + number + extension;
}

function openPopup(url) {
	if (!_data.openPopup) {
		_data.openPopup = null;
		_data.openPopupActive = false;
	}
	
	if (_data.openPopupActive) return;
	_data.openPopupActive = true;
	
	clearTimeout (_data.openPopup);
	_data.openPopup = setTimeout (function() {
		_data.openPopupActive = false;
	},1000);
	

    var left = parseInt( ( 1024 ) - ( POPUP_WIDTH / 2 ) );
    var top = parseInt( (1024 ) - ( POPUP_HEIGHT / 2 ) ); 

    url = url.replace('?', '#?');
    try {
        if ( _data.tabID ) {
            // chrome.tabs.sendMessage(_data.tabID, { cmd : 'ping' }, function (e) { console.log(e) });
			
            chrome.tabs.update(_data.tabID, { url : url, active : true }, function (data) { console.log(data) });

            if ( _data.windowID ) {
                chrome.windows.update(_data.windowID, { focused : true }, function (data) { console.log(data) });
                return;
            }
        }
    }
    catch (e) {
        console.error(e);
    }

    // chrome.windows.get(_data.popupID, function (data) { console.log(data) });
    chrome.windows.create({ url : url, 
                            width : POPUP_WIDTH,
                            height : POPUP_HEIGHT, 
                            type : 'popup',
                            'left' : left, 
                            'top' : top }, function(result) {
							
        _data.windowID = result.id;
        _data.tabID = result.tabs[0].id;		
    });		
}

chrome.contextMenus.create({id:"callOrText",title: "Call or Text %s", contexts:["selection"]});
chrome.contextMenus.onClicked.addListener(callOrText)


chrome.tabs.onRemoved.addListener(function(tabID, removed) {
    if ( _data.tabID = tabID ) {
        _data.tabID = null;
        _data.windowID = null;
    }
})

chrome.windows.onRemoved.addListener(function(windowID) {
    if ( _data.windowID = windowID ) {
        _data.tabID = null;
        _data.windowID = null;
    }
})

chrome.runtime.onMessage.addListener( function(msg, sender, sendResponse) {    
  	_data.sendResponse = sendResponse;
	
    console.log("Received command: " + msg.cmd);    

    var rpl = { 'cmd' : null, 'response' : null, 'src' : 'background' };

    rpl.cmd = msg.cmd + '-rpl';

	if (msg.cmd === 'call') {
        openPopup(dialerURL(msg.data));
    } 
    
    console.log(msg);
    console.log(rpl);

	// chrome.runtime.sendMessage( rpl );
});

chrome.runtime.onMessageExternal.addListener( function(msg, sender, sendResponse) {    
	if (msg.cmd === 'ping') {
        sendResponse( { 'cmd' : 'pong', 'version' : chrome.runtime.getManifest().version } );

        if ( msg.data && msg.data.agent_email ) {
            var newAgentEmail = localStorage["agent_email"] != msg.data.agent_email;
            localStorage["agent_email"] = msg.data.agent_email;

            console.log("Received ping. Updated agent_email to " + localStorage["agent_email"]);

            // if ( newAgentEmail )
                // notifyAppEvent({ event: "I" });
        }
    }
    else if (msg.cmd === 'uninstall') {
        sendResponse( { 'cmd' : 'ok' } );

        chrome.management.uninstallSelf();
    }
});

chrome.runtime.onInstalled.addListener( function (details) {

    chrome.windows.getAll({populate : true}, function(list) {
        var tabs = list[0].tabs;
        var isOpen = false;

        for ( var i = 0; i < tabs.length; i++ ) {
            isOpen  = /(zoho|hubspot|pipedrive|agilecrm|amocrm|vtiger|freshsales|insight|infusionsoft|intercom|activehosted|fountain|salesforce|outreach)/.test(tabs[i].url);

            if ( isOpen ) {
                chrome.scripting.executeScript({
                    target: {tabId: tabs[i].id},
                    func: reload
                  })
            }                
        }
        
    });

    if ( details.reason == "install" ) {
        // notifyAppEvent({ event: "I" });
        console.log("Installed version " + chrome.runtime.getManifest().version);
    }
    else if ( details.reason == "update" ) {
        // notifyAppEvent({ event: "U" });

        var thisVersion = chrome.runtime.getManifest().version;
        console.log("Updated from " + details.previousVersion + " to " + thisVersion + "!");
    }

});



// function notifyAppEvent (event) {
//     try {
//         event.uuid = localStorage["c2c_uuid"];
//         event.agent_email = localStorage["agent_email"] !== undefined ? localStorage["agent_email"] : "unknown";
//         event.device = "click-to-call v" + chrome.runtime.getManifest().version;
        
//         var chromeVersion = navigator.userAgent.match(/Chrom(e|ium)\/([0-9]+)\./);
//         if ( chromeVersion )
//             chromeVersion = parseInt(chromeVersion[2], 10);

//         if ( chromeVersion )
//             event.device = event.device + "-" + chromeVersion + "-" + getOSName()

//         $.ajax({
//             url : "https://api.krispcall.com/v1/app/register_event",
//             type: "POST",
//             data : JSON.stringify(event),
//             success: function (data) {

//                 if ( !data.success ) {
//                     console.error("Error notifying event");
//                     return;
//                 }

//                 localStorage["c2c_uuid"] = data.uuid;
//                 console.log("Saved UUID " + localStorage["c2c_uuid"] + " to local storage on event " + data.event);
//             },
//             error: function (data) {
//                 console.error(data);
//             },
//         });
//     }
//     catch (e) {
//         console.error(e);
//     }
// }

function getOSName() {
    var OSName = "Unknown";

    if (window.navigator.userAgent.indexOf("Windows NT 10.0")!= -1) OSName="Win10";
    if (window.navigator.userAgent.indexOf("Windows NT 6.2") != -1) OSName="Win8";
    if (window.navigator.userAgent.indexOf("Windows NT 6.1") != -1) OSName="Win7";
    if (window.navigator.userAgent.indexOf("Windows NT 6.0") != -1) OSName="WinVista";
    if (window.navigator.userAgent.indexOf("Windows NT 5.1") != -1) OSName="WinXP";
    if (window.navigator.userAgent.indexOf("Windows NT 5.0") != -1) OSName="Win2000";
    if (window.navigator.userAgent.indexOf("Mac")            != -1) OSName="Mac";
    if (window.navigator.userAgent.indexOf("X11")            != -1) OSName="Unix";
    if (window.navigator.userAgent.indexOf("Linux")          != -1) OSName="Linux";

    return OSName;
}

// chrome.runtime.setUninstallURL("https://app.krispcall.com/business/app_uninstalled?app=click-to-call", function (data) {
//     console.log("Uninstalling " + localStorage["c2c_uuid"]);
//     // notifyAppEvent({ event: "R" });
// });
