Krisp.onClick = function (data, extra) {
  var _data = {
    number: data,
    from: window.location.hostname,
  };

  if (extra) {
    _data.id = extra.id;
    _data.entity_name = extra.entity_name;
  }

  chrome.runtime.sendMessage({ cmd: "call", data: _data });
};

Krisp.getAsLink = function (number) {
  var iconURL = chrome.runtime.getURL("img/favicon.ico");
  return (
    '<a class="krisp" href="#"><img alt="Call ' +
    number +
    '" class="krisp_icon" src="' +
    iconURL +
    '"></img>' +
    number +
    "</a>"
  );
};

Krisp.btnCallIntercom = function (number) {
  var iconURL = chrome.runtime.getURL("img/favicon.ico");
  return (
    '<div class="u__left ember-view"><a class="krisp btn o__secondary o__in-right-list" href="#"><img alt="Call ' +
    number +
    '" class="krisp_icon" src="' +
    iconURL +
    '"></img>  Call</a></div>'
  );
};

Krisp.getAsIcon = function (number, extraClasses = "", addNumber = false, addTel=false) {
  var iconURL = chrome.runtime.getURL("img/favicon.ico");
  var frontText = addNumber ? number : "";
  var addTel = addTel ? `tel:${number}` : '#';
  if (extraClasses && extraClasses.indexOf("style=") >= 0)
    return `<span>${frontText}</span>&nbsp;<a class="krisp" ${extraClasses} href="${addTel}"><img alt="Call ${number}" class="krisp_icon" src="${iconURL}"></img></a>`;
  else  
   return `<span>${frontText}</span>&nbsp;<a class="krisp ${extraClasses}" href="${addTel}"><img alt="Call ${number}" class="krisp_icon" src="${iconURL}"></img></a>`;    
};

Krisp.getLogoURL = function () {
  return chrome.runtime.getURL("img/toky-logo.png");
};

Krisp.getAsIconHubspot = function (number, extraClasses = "") {
  var iconURL = chrome.runtime.getURL("img/favicon.ico");
  return (
    '<a class="krisp"' +
    extraClasses +
    ' href="#"><img alt="Call ' +
    number +
    '" class="krisp_icon" src="' +
    iconURL +
    '"></img></a>'
  );
};

Krisp.getAsIconIframe = function (
  number,
  parentExtraClasses = "",
  extraClasses = "",
  addTel = false
) {
  var iconURL = chrome.runtime.getURL("img/favicon.ico");
  var addTel = addTel ? `tel:${number}` : '#';
  return (
    '<a class="krisp"' +
    parentExtraClasses +
    ' href="'+addTel+'"><img alt="Call ' +
    number +
    '" ' +
    extraClasses +
    ' class="krisp_icon" src="' +
    iconURL +
    '"></img></a>'
  );
};

Krisp.logoOnTop = function (element, extraClasses) {
  var logo = chrome.runtime.getURL("img/favicon.ico");
  var _class = extraClasses ? extraClasses : "";

  if (element !== undefined)
    return (
      "<" +
      element +
      ' class="' +
      _class +
      '"><span class="krisp_logo"><img src="' +
      logo +
      '"></span></' +
      element +
      ">"
    );
  else return '<span class="krisp_logo"><img src="' + logo + '"></span>';
};

Krisp.insertClickToCall = function (e, phoNumber) {
  var number = !phoNumber ? "" : phoNumber;
  e.preventDefault();
  e.stopPropagation();
  console.log("-- 📞 " + number);
  Krisp.onClick(number, e.numberData);
};

$(document).ready(function () {
  console.log("-- Krisp was loaded");
  Krisp.init();
});

$(window).click(function () {
  console.log("-- Looking for numbers");
  timer = setTimeout(Krisp.init, 1000);
});
