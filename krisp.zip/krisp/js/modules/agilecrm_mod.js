var Toky = {};
var timer = null;
var timeSpent = 0;

function injectContactPage() {
	var found = false;
	
	// Contacts detail

	var elements = $('a.contact-make-call');

	try {
		elements.each( function (index) {
			var element = $(this);

			var number = element.attr("phone")

			if ( element.attr("phone") !== undefined ) {
				
				if ( element.parent().find('a.toky').length === 0 ) {
					element.parent().append( function () {
						return $(Toky.getAsIcon(number)).click(function(e) { Toky.insertClickToCall(e, number); });
					});
					found = true;
				}
			}

		});

	}
	catch (e) {
		console.error(e);
	}	

	return found;

}
// Contact list

function injectContactList(){
	var patt = /^[+]*([0-9]+)$/;
	var found = false;
	var elements =  $('div.text-ellipsis a.text-cap:not(:empty)')


	try {
		elements.each( function (index) {
			var element = $(this);
			var number = element.html();

			if (patt.test(number)) {
				
				if ( number !== undefined  && element.find('a.toky').length === 0 ) {
					element.html( function () {
						return $(Toky.getAsLink(number)).click(function(e) { Toky.insertClickToCall(e, number); });
					});
					found = true;
				}
			}
			

		});
	}
	catch (e) {
		console.error(e);
	}	
	return found;
}

function injectInCustomFields(){
	var found = false;
	var elements =  $('span.contact-custom-value');


	try {
		elements.each( function (index) {
			var element = $(this);
			var number = element.html();

			if (element.attr('name').match(/phone/gi)) {
				
				if ( number !== undefined  && element.find('a.toky').length === 0 ) {
					element.html( function () {
						return $(Toky.getAsLink(number)).click(function(e) { Toky.insertClickToCall(e, number); });
					});
					found = true;
				}
			}
			

		});
	}
	catch (e) {
		console.error(e);
	}	
	return found;
}
	

function inject() {

	$header = $('ul.nav.navbar-nav.navbar-right.show_shortcuts:first');
    $logo = $header.find( "li span.toky_logo" );
    if ($logo.length===0) $header.prepend($(Toky.logoOnTop('li')).click(function(e) { Toky.insertClickToCall(e); }));


	var found = injectContactList();
	var foundInContactPage = injectContactPage();
	var foundInCustomFields = injectInCustomFields();

	found = found || foundInContactPage || foundInCustomFields;

	if ( found ) {
		clearTimeout(timer);
		timeSpent = 0;
		return;
	}

	timer = setTimeout(inject, 1000);
	timeSpent += 1000;

	if ( timeSpent > 4000 ) {
		clearTimeout(timer);
		timeSpent = 0;
	}
}

$(window).on('popstate', function() {
	setTimeout(inject, 500);
});

Toky.init = function() {
	inject();
};
