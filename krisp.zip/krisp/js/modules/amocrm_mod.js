var Toky = {};
var timer = null;
var timeSpent = 0;

function injectCustomFields() {
	var found = false;
	var elements = $('div.linked-form__field__label');

	try {
		elements.each( function (index) {

			var element = $(this);
			element = element.find("span");

			if ( element !== undefined && element.html() !== undefined && ( element.html().toLowerCase().indexOf("fono") >= 0 || 
				element.html().toLowerCase().indexOf("phone") >= 0 || 
				element.html().toLowerCase().indexOf("celu") >= 0 || 
				element.html().toLowerCase().indexOf("cell") >= 0 || 
				element.html().toLowerCase().indexOf("mobile") >= 0 ) ) {

				var parent = $(this).parent(); //.parent().parent();
				var input 	= parent.find('input');
				var number = input.attr("value").replace(/[^\+0-9]/g,'');
		
	    		var regExp = /[\+0-9]/g;
	    		var isNumber = regExp.test(number);

			if ( input.parent().find('a.toky').length === 0 && isNumber) {

				if ( input.length !== 0 && input.attr("value") !== undefined && input.attr("value").trim() != "" ) {

					input.parent().append( function () {
						
						return $(Toky.getAsIcon(number, 'style="position: absolute;top: 6px;right: 20px;width: 16px;"')).click(function(e) { Toky.insertClickToCall(e, number); });
					});
					found = true;
				}
			}

		}

	});
	}
	catch (e) {
		console.error(e);
	}
	checked = found;
	return found;
}

function injectContactPage() {
	
	var found = false;

	try {
		elements = $('.js-control-phone.control-phone');

		elements.each( function (index) {

			var element = $(this);
			var input 	= element.find('input');
			var number = input.attr("value");
			
			if ( element.find('a.toky').length === 0 && number.length > 3 ) {
				if ( input.length !== 0 && input.attr("value") && input.attr("value") !== undefined && input.attr("value").trim() != "" ) {

					// console.log(input.attr("name"));
					// console.log(input.attr("value"));

					element.append( function () {
						return $(Toky.getAsIcon(number, 'style="position: absolute;top: 6px;right: 20px;width: 16px;"')).click(function(e) { Toky.insertClickToCall(e, number); });
					});
					found = true;
				}
			}

		});	

	}
	catch (e) {
		console.error(e);
	}
	checked = found;
	return found;
}

function injectContactList() {
	var found = false;
	var elements = $('div.content-table__item__inner');

	try {
		elements.each( function (index) { 
			var element = $(this).find('a').filter( function() {
				return $(this).attr("data-action-code") !== undefined && $(this).attr("data-action-code").toLowerCase().indexOf("phone") >= 0;
			} );

			if ( element && element.attr("data-value") !== undefined && element.attr("data-value").trim() != "") {
				element.html( function () { 
					var number = element.attr("data-value");
					return $(Toky.getAsLink(number)).click(function(e) { Toky.insertClickToCall(e, number); });
				})
				found = true;    		
			}

		});
	}
	catch (e) {
		console.error(e);
	}    
	checked = found;
	return found;
}

function inject() {

	$header = $('div.list__top__actions');
	$logo = $header.find( "span.toky_logo" );
	if ($logo.length===0) $header.prepend($(Toky.logoOnTop()).click(function(e) { Toky.insertClickToCall(e); }));


	var found = injectContactList();
	var foundInContactPage = injectContactPage();
	var foundCustomFields = injectCustomFields();

	found = found || foundInContactPage || foundCustomFields;

	if ( found ) {
		clearTimeout(timer);
		timeSpent = 0;
		return;
	}

	timer = setTimeout(inject, 1000);
	timeSpent += 1000;

	if ( timeSpent > 4000 ) {
		clearTimeout(timer);
		timeSpent = 0;
	}
}

$(document).keypress(function(e) {
	if( e.which == 13 ) {
		setTimeout(inject, 500);
	}
});

$(window).on('popstate', function() {
	setTimeout(inject, 500);
});

$("div").on('click', function() {
	setTimeout(inject, 500);
});


var checked = false;
var currentPage =  null;

function checkCurrentPage() {
	checked = (currentPage == location.pathname) ? true : false;

	currentPage = location.pathname;
		
	if( currentPage.match(/detail/) && !checked) {
		injectContactPage();
		injectCustomFields();
	}

	if( currentPage.match(/list/) && !checked) {
		injectContactList();
	}

	checked = true

	
	setTimeout(function() {
		checkCurrentPage(); 
	}, 1500);
	
	
}

Toky.init = function() {
	inject();
	checkCurrentPage();
};
