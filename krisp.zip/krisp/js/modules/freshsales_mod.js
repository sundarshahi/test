var Toky = {};
var timer = null;
var timeSpent = 0;

function injectContactPage() {
	var found = false;
	
	// Contacts detail

	var elements = $('div.card-desc div.mg-b-15:first div[id*=ember].ember-view span[class=" "]');

	if (elements.length==0) elements = $('div.card-desc div.mg-b-15:first div[id*=ember].ember-view a span');

	try {
		elements.each( function (index) {
			var element = $(this);

			// var number = element.html().trim();
			var number = element.text().trim().replace(/[^\+0-9]/g,'');
			
			if ( number && number.length > 5) {
				
				if ( element.find('a.toky').length === 0 ) {
					element.append( function () {
						return $(Toky.getAsIcon(number)).click(function(e) { Toky.insertClickToCall(e, number); });
					});
					found = true;
				}
			}

		});

	}
	catch (e) {
		console.error(e);
	}	

	return found;

}
// Contact list

function injectContactList(){
	
	var found = false;
	var elements = $('span[data-test-inline-edit-content] div[id*=ember].ember-view a[data-ember-action]');

	if (elements.length == 0 ) {
		elements = $('td div.phone-content div.text-ellipsis').filter(function(){
			var $number = $(this).text().trim().replace(/[^\+0-9]/g,'');
			// return ($class && $class.match(/^[0-9 \+-]{2,}$/));
		
			return ($number)
		});
	}

	try {
		
		elements.each( function (index) {
			var element = $(this);
			var number = element.text().trim().replace(/[^\+0-9]/g,'');
			
			if ( number.length > 3 && element.find('a.toky').length === 0 ) {
				element.append( function () {
						return $(Toky.getAsIcon(number)).click(function(e) { Toky.insertClickToCall(e, number); });
					});
				found = true;
			}
					

		});
	}
	catch (e) {
		console.error(e);
	}	
	return found;
}

function injectDealsPage(){
	var found = false;

	var elements = $('div.card-desc div.mg-b-15:first div[id*=ember].ember-view span[class=" "]');

	if (elements.length==0) elements = $('div.card-desc div.mg-b-15:first div[id*=ember].ember-view a span');


	try {
		elements.each( function (index) {
			var element = $(this);
			var number = element.text();
			
			if ( number !== undefined  && element.parent().find('a.toky').length === 0 ) {
				element.append( function () {
						return $(Toky.getAsIcon(number)).click(function(e) { Toky.insertClickToCall(e, number); });
					});
				found = true;
			}
					

		});
	}
	catch (e) {
		console.error(e);
	}	
	return found;
}
	

function inject() {

	$header = $('ul.navbar-personal-links:first');
    $logo = $header.find( "li span.toky_logo" );
    if ($logo.length===0) $header.prepend($(Toky.logoOnTop('li','navbar-personal-item')).click(function(e) { Toky.insertClickToCall(e); }));


	var found = injectContactPage();
	var foundInContactPage =injectContactList();
	var foundInDealsPage = injectDealsPage();

	found =  found || foundInContactPage || foundInDealsPage;


	if ( found ) {
		clearTimeout(timer);
		timeSpent = 0;
		return;
	}

	timer = setTimeout(inject, 1000);
	timeSpent += 1000;

	if ( timeSpent > 4000 ) {
		clearTimeout(timer);
		timeSpent = 0;
	}

}

$(window).on('popstate', function() {
	setTimeout(inject, 500);
});

Toky.init = function() {
	inject();

	setTimeout(inject, 13000);
	
};
