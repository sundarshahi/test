var Toky = {};
var timer = null;
var timeSpent = 0;

function inject() {
	
	console.log("injecting");

	var found = false

	$('table').each(function(index) {
		var table = $(this);

		table.find("tr").each( function() {
	  		var row = $(this);
	  		var c = row.find('td:nth-child(6)');
  			var number = c.text();
  			var foundTokyMark = c.find('a.toky').length != 0;
  			
  			if ( !foundTokyMark && number ) {
  				
  				console.log("adding!");
  				var div = c.find("div");
  				c.find("div").each(function (index) {

  					if ( $(this).text() && $(this).text().startsWith("(") ) // "(+1)" extra numbers
  						return true; // continue

  					$(this).html(function () { return $(Toky.getAsLink(number)).click(function(e) { Toky.insertClickToCall(e, number); } ); });	
  				})
  				

  				foundTokyMark = true;
  			}

  			found = foundTokyMark;
		});
	});

	if ( found ) {
		clearTimeout(timer);
		timeSpent = 0;
		return;
	}

	timer = setTimeout(inject, 1000);
	timeSpent += 1000;

	if ( timeSpent > 3000 ) {
		clearTimeout(timer);
		timeSpent = 0;
	}
}

$(window).on('popstate', function() {
	
	setTimeout(inject, 500);
});

Toky.init = function() {
	inject();
};
