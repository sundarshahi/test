var Toky = {
        interval:null,
        extraControl:false
    },    
    className='toky-tag-controler';

function inject() {   
    let $header = $('a[href^="tel:"]').parent().not(`.${className}`),
        $hover = $('[data-content_popper_hover_guid]').not(`.${className}`);

    if ($hover.length>0) {
        $hover.each(function(){            
            $(this).hover(function(){
                inject();  
            }).addClass(className);                      
        });        
    }

    if ($header.length>0) {
        $header.addClass(className).prepend(
            $(Toky.logoOnTop("div",'sm')).click(function (e) {
                let number = $(this).parents(`.${className}`).find('a[href^="tel:"]').attr('href').replace('tel:','');
                Toky.insertClickToCall(e,number);
            })
        ).find('a[href^="tel:"]').click(function(e){
            let number = this.getAttribute('href').replace('tel:','');
            Toky.insertClickToCall(e,number);            
        });
    }
}

function extraControl() {
    clearInterval(Toky.interval);
    Toky.interval = setTimeout(function(){
        inject();  
        extraControl();
    }, 1500);
}

Toky.init = function () {        
    if (!Toky.extraControl) {
        Toky.extraControl = true;
        inject();
    }
    extraControl()
};
