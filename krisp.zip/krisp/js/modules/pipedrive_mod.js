var Krisp = {};
var timer = null;
var timeSpent = 0;
var found = false;

function inject() {
	// console.log("-- checking");
	// var elements = $('span.value');
	var configElement = function(element,regexp) {
		element.click(function() {
			// console.log('element', this);
			// console.log('number', this.callNumber);
			// console.log('data', this.numberData);
			Krisp.insertClickToCall(this, this.callNumber);
			return false
		})
	}

	var elements = $('a[href*="callto"],a[href*="tel"],a[href*="skype"],a[href*="facetime"]'), regexp = new RegExp('^(callto|tel|skype|facetime)\:', 'g');
	elements.each(function(index){

		var numberData = {};

		if (location.pathname.match(/^\/(organization)/i)) {
			numberData.entity_name = 'organization';
		} else
		if (location.pathname.match(/^\/(person)/i)) {
			numberData.entity_name = 'person';
		} else
		if (location.pathname.match(/^\/(deal)/i)) {
			numberData.entity_name = 'deal';
		}

		if (location.pathname.match(/^\/(deal|person|organization)\/[0-9]+$/i)) {
			numberData.id = location.pathname.replace(/[^0-9]+/i, '');
		} else {
			var search = $(this).parents('tr');
			if (search.length>0) {
				search = search.find('[data-field="name"] a');
				if (search.length>0) {
					if (search.attr('href').match(/\/(person|deal|organization)\/[0-9]+$/i) ) {
						numberData.id = search.attr('href').replace(/[^0-9]+/, '');
					}
				}
			}
		}		
		
		this.numberData = numberData;
		this.callNumber = this.href.replace(regexp,'');
		if (!this.preventDefault) this.preventDefault = function(){};
		if (!this.stopPropagation) this.stopPropagation = function(){};		
		
		if (this.href.match(regexp) && this.krispEventClick==undefined) {
			this.krispEventClick = true;
			this.setAttribute('style', 
					'background-image: url('+chrome.runtime.getURL("img/favicon.ico")+') !important;'+
    				'padding-right: 20px;'+
				    'background-size: 15px;'+
				    'background-repeat: no-repeat;'+
				    'background-position: left;'+
				    'backface-visibility: visible;'+
					'padding-left: 20px;');								
			
			configElement($(this), regexp);						
		}
	});
    
	$header = $( ".user-profile-corner" );
    $logo = $header.find( "span.krisp_logo" );
    if ($logo.length===0) $header.prepend($(Krisp.logoOnTop()).click(function(e) { Krisp.insertClickToCall(e); }));
	
}

var _prevPage = null;
var _checking = false;
var _counter = 1;

function checkCurrentPage() {
    
    if ( _checking )
    	return;

    _checking = true;
    inject();
	setTimeout(function() { 
		_checking = false;	
		checkCurrentPage(); 
	}, 2000);
}


$(window).on('popstate', function() {
	inject();
});

Krisp.init = function() {
	found = false;
	checkCurrentPage();
};