var Toky = {};
var timer = null;
var timeSpent = 0;

// Contact list

function injectContactList(){
	var found = false;
	var elements = $('a.phoneField');


	try {
		elements.each( function (index) {
			var element = $(this);
			var number = element.html();
			
			if ( number !== undefined  && element.parent().find('a.toky').length === 0 ) {
				element.parent().html( function () {
					return $(Toky.getAsLink(number)).click(function(e) { Toky.insertClickToCall(e, number); });
				});
				found = true;
			}
					

		});
	}
	catch (e) {
		console.error(e);
	}	
	return found;
}
	

function inject() {

	$header = $('ul.topbar-icons');
    $logo = $header.find( "li span.toky_logo" );
    if ($logo.length===0) $header.prepend($(Toky.logoOnTop('li')).click(function(e) { Toky.insertClickToCall(e); }));


	var found = injectContactList();

	if ( found ) {
		clearTimeout(timer);
		timeSpent = 0;
		return;
	}

	timer = setTimeout(inject, 1000);
	timeSpent += 1000;

	if ( timeSpent > 4000 ) {
		clearTimeout(timer);
		timeSpent = 0;
	}
}

$(window).on('popstate', function() {
	setTimeout(inject, 500);
});

Toky.init = function() {
	inject();
};
